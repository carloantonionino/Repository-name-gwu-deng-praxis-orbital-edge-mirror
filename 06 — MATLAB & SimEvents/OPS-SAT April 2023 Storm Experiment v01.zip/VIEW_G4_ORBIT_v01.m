function r = VIEW_G4_ORBIT_v01(tleFile,varargin)
% VIEW_G4_ORBIT_V01  Proposed 2023 orbital geometry, NOT reception proof.
% Requires ACTUAL OPS-SAT 2023 TLE obtained from a dated archive.
% Never reuse 2022 TLE for April 2023 orbital playback.
%
% Example after a VERIFIED 2023 TLE is acquired:
% r = VIEW_G4_ORBIT_v01('historical tle/OPS_SAT_44878_2023_04_23.tle', ...
%    'startUTC',datetime(2023,4,23,19,30,0,'TimeZone','UTC'), ...
%    'minutes',12,'speed',2);
%
% Same four map points as v07; 2023 site operation/antenna configuration
% and recorded receptions HAVE NOT BEEN VERIFIED.

p = inputParser;
addParameter(p,'startUTC',datetime(2023,4,23,19,30,0,'TimeZone','UTC'));
addParameter(p,'minutes',12,@(x)isnumeric(x)&&isscalar(x)&&x>0);
addParameter(p,'speed',2,@(x)isnumeric(x)&&isscalar(x)&&x>0);
parse(p,varargin{:});
startUTC = p.Results.startUTC;
assert(~isempty(startUTC.TimeZone),'startUTC must have a UTC time zone.');
assert(isfile(tleFile),'No 2023 TLE supplied. A 2022 TLE must not be reused.');
lines = splitlines(string(fileread(tleFile)));
lines = strtrim(lines);
idx1 = find(startsWith(lines,'1 44878U'),1,'first');
idx2 = find(startsWith(lines,'2 44878 '),1,'first');
assert(~isempty(idx1)&&~isempty(idx2),'Expected NORAD 44878 TLE lines.');
l1 = char(lines(idx1));
yy = str2double(l1(19:20));
doy = str2double(l1(21:32));
assert(yy==23 && isfinite(doy),'TLE is not from 2023.');
epochUTC = datetime(2000+yy,1,1,'TimeZone','UTC') + days(doy-1);
assert(abs(days(startUTC-epochUTC))<=7, ...
    'TLE epoch is more than 7 days from the visualized date. Acquire a contemporaneous TLE.');

sc = satelliteScenario(startUTC,startUTC+minutes(p.Results.minutes),1);
sat = satellite(sc,tleFile,'Name','OPS-SAT 44878 (2023 TLE)', ...
    'OrbitPropagator','sgp4');
sat.MarkerColor=[0.19 0.83 0.99];
sat.MarkerSize=10;
siteNames = {'ESA ESTEC [839, 2023 UNVERIFIED]', ...
    'DL5FAB [2504, 2023 UNVERIFIED]', ...
    'EA6TC [JM19jn PROVISIONAL]', ...
    'EU1XX [KO33ru PROVISIONAL]'};
lat=[52.217 49.859 39.559 53.854167];
lon=[4.423 8.660 2.781 27.458333];
alt=[5 220 0 0];
minEl=[5 10 10 10];
G=cell(4,1);A=cell(4,1);
for k=1:4
    G{k}=groundStation(sc,lat(k),lon(k), ...
        'Altitude',alt(k),'MinElevationAngle',minEl(k), ...
        'Name',siteNames{k});
    A{k}=access(sat,G{k});
    if k<=2
        G{k}.MarkerColor=[0.2 0.84 0.53];
        A{k}.LineColor=[0.2 0.84 0.53];
    else
        G{k}.MarkerColor=[1 0.65 0.19];
        A{k}.LineColor=[1 0.65 0.19];
    end
    G{k}.MarkerSize=9;
    A{k}.LineWidth=2;
end
viewer=satelliteScenarioViewer(sc);
show(sat);
for k=1:4, show(G{k});show(A{k});end
try
    groundTrack(sat,'LeadTime',600,'TrailTime',600);
catch ME
    warning('Ground track unavailable: %s', ME.message);
end
fprintf('2023 OPS-SAT GEOMETRY ONLY. No 2023 receiver evidence verified.\n');
fprintf('2023 TLE epoch: %s\n',char(epochUTC));
fprintf('Site coordinates are v07 candidates, NOT verified 2023 hardware.\n');
fprintf('No RF impairment or signal strength is calculated.\n');
r=struct('scenario',sc,'satellite',sat,'stations',{G}, ...
    'accesses',{A},'viewer',viewer,'tleEpochUTC',epochUTC);
play(sc,'PlaybackSpeedMultiplier',p.Results.speed);
end
