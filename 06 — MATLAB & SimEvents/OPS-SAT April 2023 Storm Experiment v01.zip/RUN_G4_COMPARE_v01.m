function results = RUN_G4_COMPARE_v01(varargin)
% RUN_G4_COMPARE_V01  Controlled two-environment Ground/Edge DES replay.
%
% IMPORTANT EVIDENCE BOUNDARY
% This is the frozen January 2022 ACE workload replayed under an ASSUMED
% communications impairment during the DOCUMENTED 23 April 2023 G4 storm.
% The code DOES NOT claim 2023 OPS-SAT receptions, a measured UHF impairment,
% a measured Kp-to-bandwidth relationship, or observed orbital-edge speed.
%
% Runs unchanged, existing Baseline 2 DES functions. It writes ONLY inside
% the folder containing this file and does NOT edit the original Baseline 2.
%
% Example for a quick, 10-replication check:
%   r = RUN_G4_COMPARE_v01('reps',10,'rateFactor',0.5);
%
% 20,000 architecture executions across the 2 environments x 2 paths:
%   r = RUN_G4_COMPARE_v01('reps',5000,'rateFactor',0.5);
%
% RATEFACTOR 0.5 IS A TEST ASSUMPTION, NOT A MEASURED APRIL 2023 LOSS.

p = inputParser;
defaultBaseline = fullfile('C:\Users\carlo\OneDrive\Desktop\AA GWU PRAXIS', ...
    'PRIME','Mtg 5 - Oct 30, 2026','MATLAB docs','MATLAB V1', ...
    'MATLAB_Baseline2_Simultaneous_ACE');
addParameter(p,'baselineDir',defaultBaseline,@(x)ischar(x)||isstring(x));
addParameter(p,'reps',10,@(x)isnumeric(x)&&isscalar(x)&&isfinite(x)&&x>=2&&x==floor(x));
addParameter(p,'rateFactor',0.5,@(x)isnumeric(x)&&isscalar(x)&&isfinite(x)&&x>0&&x<=1);
addParameter(p,'stormDownSeconds',120,@(x)isnumeric(x)&&isscalar(x)&&isfinite(x)&&x>=0);
parse(p,varargin{:});
opts = p.Results;
baseDir = char(opts.baselineDir);
assert(isfile(fullfile(baseDir,'des_load.m')), 'Cannot find the original DES functions. Check baselineDir.');
assert(isfile(fullfile(baseDir,'data','ace_cohort.csv')), 'Cannot find the frozen ACE cohort.');
addpath(baseDir);

% Ground and Edge receive identical event arrivals and processing draws.
M0 = des_load(fullfile(baseDir,'data'));
assert(M0.cfg.entities==100, 'Expected 100 frozen January 2022 ACE observations.');
assert(M0.cfg.up==600 && M0.cfg.down==120, ...
    'Original 600-up / 120-down baseline differs. Inspect before proceeding.');
assert(all(abs(M0.cohort.rate-100)<1e-10), ...
    'Baseline link rates differ from 100 Mbps. Inspect baseline configuration.');
M0.cfg.replications = opts.reps;

% Counterfactual storm case: SAME January 2022 workload, assumed impairment.
M1 = M0;
M1.cohort.rate = M0.cohort.rate * opts.rateFactor;
M1.cfg.down = opts.stormDownSeconds;
M1.cfg.cycle = M1.cfg.up + M1.cfg.down;

% The existing whole-item contact-window policy cannot complete a task
% requiring more link time than any available up window.
gTx = M1.cfg.rawMb * 8 ./ M1.cohort.rate + M1.cohort.prop;
eTx = M1.cfg.rawMb * M1.cfg.outFraction * 8 ./ M1.cohort.rate + M1.cohort.prop;
assert(all(gTx<=M1.cfg.up) && all(eTx<=M1.cfg.up), ...
    'Some transmissions exceed the contact duration. No fragmentation policy is implemented.');

% Use the same original DES function in both environments.
[T0,~] = des_replicate(M0,M0.cfg.rawMb,M0.cfg.groundMean, ...
    M0.cfg.edgeMean,M0.cfg.outFraction,0);
[T1,~] = des_replicate(M1,M1.cfg.rawMb,M1.cfg.groundMean, ...
    M1.cfg.edgeMean,M1.cfg.outFraction,0);

% Two architectures inside each environment; then compare the advantage.
D0 = T0.gMean - T0.eMean;
D1 = T1.gMean - T1.eMean;
I = D1 - D0;
ci = @(x) localCI(x,M0.cfg.alpha);
ci0 = ci(D0); ci1 = ci(D1); ciI = ci(I);

condition = {'2022 frozen ACE workload / original link'; ...
             '2022 frozen ACE workload / 2023 G4 CONTEXT + assumed link change'};
meanGround_s = [mean(T0.gMean);mean(T1.gMean)];
meanEdge_s = [mean(T0.eMean);mean(T1.eMean)];
edgeAdvantage_s = [mean(D0);mean(D1)];
withinDeadlineGround_pct = 100*[mean(T0.gWithin);mean(T1.gWithin)];
withinDeadlineEdge_pct = 100*[mean(T0.eWithin);mean(T1.eWithin)];
notStaleGround_pct = 100*[mean(T0.gDeliv);mean(T1.gDeliv)];
notStaleEdge_pct = 100*[mean(T0.eDeliv);mean(T1.eDeliv)];
meanQueueGround_s = [mean(T0.gWait);mean(T1.gWait)];
meanQueueEdge_s = [mean(T0.eWait);mean(T1.eWait)];
S = table(condition,meanGround_s,meanEdge_s,edgeAdvantage_s, ...
    withinDeadlineGround_pct,withinDeadlineEdge_pct, ...
    notStaleGround_pct,notStaleEdge_pct,meanQueueGround_s,meanQueueEdge_s);

% Report an independently auditable result directory for EACH new run.
root = fileparts(mfilename('fullpath'));
outRoot = fullfile(root,'outputs');
if ~isfolder(outRoot), mkdir(outRoot); end
runName = ['G4_COUNTERFACTUAL_' datestr(now,'yyyymmdd_HHMMSSFFF')];
outDir = fullfile(outRoot,runName);
mkdir(outDir);
writetable(S,fullfile(outDir,'Comparison.csv'));
R = table((1:opts.reps)',T0.gMean,T0.eMean,T1.gMean,T1.eMean,D0,D1,I, ...
    'VariableNames',{'replication','groundNormal_s','edgeNormal_s', ...
    'groundAssumedStorm_s','edgeAssumedStorm_s', ...
    'advantageNormal_s','advantageAssumedStorm_s','interaction_s'});
writetable(R,fullfile(outDir,'Replications.csv'));
manifest = struct('label','APRIL 2023 G4 CONTEXT / COUNTERFACTUAL LINK STRESS', ...
    'baselineACEyear',2022,'baselineDate','2022-01-28', ...
    'stormDate','2023-04-23','documentedStormStartUTC','2023-04-23T17:37:00Z', ...
    'selectedStormWindowUTC','2023-04-23T18:00:00Z/2023-04-23T21:00:00Z', ...
    'observedKp','8+ (three-hour window, NOT a link-loss measurement)', ...
    'rateFactorAssumed',opts.rateFactor, ...
    'normalRateMbps',100,'stormRateMbpsAssumed',100*opts.rateFactor, ...
    'normalDownSeconds',120,'stormDownSecondsAssumed',opts.stormDownSeconds, ...
    'repsPerCondition',opts.reps, ...
    'totalArchitectureExecutions',4*opts.reps, ...
    'meansOfHistorical2023RF',false,'simultaneous2023ACEVerified',false, ...
    'no2023TLEUsedInDES',true, ...
    'source1','https://swpc-drupal.woc.noaa.gov/news/update-g4-storm-observed-sunday-april-23-2023', ...
    'source2','https://doi.org/10.1051/swsc/2025001', ...
    'interpretation','Conditional simulation ONLY. Storm Kp does NOT calibrate communication loss.');
fid=fopen(fullfile(outDir,'RunManifest.json'),'w');
assert(fid>0,'Could not create run manifest.');
fwrite(fid,jsonencode(manifest),'char'); fclose(fid);

fprintf('\n=== APRIL 2023 G4 / CONTROLLED DES REPLAY ===\n');
fprintf('Existing ACE 100-event cohort: January 2022, FROZEN.\n');
fprintf('Observed storm window: 2023-04-23 18:00-21:00 UTC (NOAA G4).\n');
fprintf('Assumed storm link factor: %.2f (NOT measured).\n',opts.rateFactor);
fprintf('Replications: %d per environment, %d total architecture executions.\n', ...
    opts.reps,4*opts.reps);
disp(S);
fprintf('Advantage baseline: %9.3f s  95%% CI [%9.3f, %9.3f]\n', ...
    ci0(1),ci0(2),ci0(3));
fprintf('Advantage stress:   %9.3f s  95%% CI [%9.3f, %9.3f]\n', ...
    ci1(1),ci1(2),ci1(3));
fprintf('Difference of advantages I: %9.3f s  95%% CI [%9.3f, %9.3f]\n', ...
    ciI(1),ciI(2),ciI(3));
fprintf('COUNTERFACTUAL RESULT. NO measured 2023 signal degradation established.\n');
fprintf('Outputs: %s\n',outDir);

fig=figure('Color','white','Name','Ground / Edge baseline vs assumed storm');
bar(categorical({'Normal (2022 workload)','Assumed stress (G4 context)'}), ...
    [meanGround_s meanEdge_s]);
ylabel('Mean end-to-end latency (seconds)');
legend('Ground','Edge','Location','northwest');
title('Matched DES architecture comparison: scenario assumptions, not RF measurements');
set(fig,'Position',[100 100 980 560]);
saveas(fig,fullfile(outDir,'MeanLatency.png'));

results = struct('table',S,'normal',T0,'assumedStorm',T1, ...
    'ciNormal',ci0,'ciStorm',ci1,'ciInteraction',ciI, ...
    'assumedRateFactor',opts.rateFactor,'outputDirectory',outDir);
end

function ci = localCI(x,alpha)
n = numel(x);
mu = mean(x);
h = des_tcrit(alpha,n-1)*std(x)/sqrt(n);
ci=[mu,mu-h,mu+h];
end
