OPS-SAT April 23 2023 G4 storm | Controlled experiment v01
Created November 13, 2026. Research configuration, NOT empirical storm-link validation.

WHAT IS VERIFIED
- NOAA confirmed a severe (G4) geomagnetic storm on April 23, 2023.
- A NOAA alert placed the severe storm at approximately 19:44 UTC.
- Published peer-reviewed work reports Kp 8+ for 18:00–21:00 UTC.
- Your original Baseline 2 uses 100 January 2022 ACE observations, 100-Mbps
  *synthetic* link, 600 s up/120 s down, 300 MB input, 25% output fraction.

WHAT IS NOT VERIFIED
- OPS-SAT receptions by the four January 2022 stations at the 2023 storm time.
- A contemporaneous 2023 TLE in this package (NO historical TLE was invented).
- The 2023 mission-specific AI/ML workload corresponding to the same storm.
- 2023 historical antenna configurations, received signal strength, link loss,
  outage schedule, or a physical Kp-to-communications relationship.

STAGE 1 | COUNTERFACTUAL MODEL USING OUR EXACT ORIGINAL MATLAB ENGINE
Place this v01 folder on your PC, separately from the original Baseline 2.
In MATLAB Command Window:
  cd('PATH TO THE EXTRACTED V01 FOLDER')
  addpath(pwd)
  r = RUN_G4_COMPARE_v01('reps',10,'rateFactor',0.5);

It reads the original MATLAB_Baseline2_Simultaneous_ACE folder automatically
at C:\Users\carlo\OneDrive\Desktop\AA GWU PRAXIS\PRIME\Mtg 5 - Oct 30, 2026\MATLAB docs\MATLAB V1\MATLAB_Baseline2_Simultaneous_ACE
Pass 'baselineDir','PATH' if your folder name differs.

0.5 = an illustrative 50% rate decrease, NOT measured in April 2023.
The 2022 workload, random processing draws, deadline and original processing
order remain unchanged in both conditions. Both architectures have an
identical new link in the stress case. No baseline data is modified.

Four experimental cells: Normal Ground, Normal Edge, Assumed-Stress Ground,
Assumed-Stress Edge. Delta = Ground latency - Edge latency;
I = Delta(stress) - Delta(normal). Positive I = the edge advantage increased.

The original experiment includes 10 replications for a first smoke test.
After validating inputs and outputs, 5,000 paired repeats of the four cells
would equal 20,000 architecture executions in total:
  r = RUN_G4_COMPARE_v01('reps',5000,'rateFactor',0.5);
Do not call these runs historical measurements or 2023 calibration.
Separate alternative rate factors (0.75, 0.5, etc.) are sensitivity cases,
NOT combined into the count above unless explicitly defined.

STAGE 2 | HISTORICAL 2023 GEOMETRY
Use VIEW_G4_ORBIT_v01 only after acquiring a TLE with 2023 epoch
near April 23. Do NOT reuse OPS_SAT_44878_SELECTED_2022-01-28.tle.
The 2023 viewer uses the same four location markers and classic Earth map.
A drawn access line only establishes *modeled line of sight* at that time.
It does not establish a received packet, throughput or environmental fade.

STAGE 3 | STRONGER HISTORICAL CASE (NOT IN v01)
Obtain 2023 SatNOGS Network/SiDS receptions, correct TLE, NASA OMNI
1-min solar-wind data, Kp index, and direct RF evidence. Obtain 2023
AI/ML telemetry or explicitly label the workload as a 2022 replay.
Do not assign storm packet-loss or rate penalties from Kp alone.

ORIGINAL DES SOURCE
Green Praxis original folder MATLAB_Baseline2_Simultaneous_ACE
Core functions: des_load, des_replicate, des_run_rep, des_tcrit.
No original program, workbook, or verified v05/v07 files are overwritten.
Outputs are saved in a new timestamped outputs subfolder here.

REFERENCES
NOAA storm notice:
https://swpc-drupal.woc.noaa.gov/news/update-g4-storm-observed-sunday-april-23-2023
NOAA renewed G4:
https://swpc-drupal.woc.noaa.gov/news/update-geomagnetic-storm-has-re-strengthened-g3-g4
Peer-reviewed European sector study:
https://doi.org/10.1051/swsc/2025001
NASA OMNI explorer:
https://omniweb.gsfc.nasa.gov/form/omni_min.html
SatNOGS observation API parameters:
https://librespacefoundation.gitlab.io/-/satnogs/satnogs-network/-/jobs/1380080108/artifacts/satnogs-network-api-client/html2/index.html

EXECUTION STATUS
MATLAB R2026a execution NOT performed here.
All MATLAB results must be checked on user's licensed installation.
