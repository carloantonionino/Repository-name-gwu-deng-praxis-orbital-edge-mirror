OPS-SAT historical viewer v06: original v04 look plus illustrative orange antenna blooms.
Date: 2026-11-11. NO changes to v05, historical inputs, DES or its parameters.

Copy both .m files into your MATLAB Current Folder (or add their folder to path).
First run RUN_RECEPTION_CHECK_v05, as already completed on November 11.

RUN IN MATLAB:
  addpath('FOLDER_CONTAINING_THE_TWO_M_FILES')
  v = praxis_ops_sat_viewer_v06('speed',5,'blooms','all');

For a less crowded display, use 'blooms','satellite'.
For no blooms use 'blooms','off'.
To slow down further use 'speed',2, or 'speed',1 for actual-time playback.

AFTER PLAYBACK, WHEN YOU WANT THE SEPARATE EVIDENCE FIGURE:
  praxis_ops_sat_evidence_v06(v)

Original Earth view, ground stations, cyan/yellow tracks, green Network,
amber provisional SiDS, and native viewer transport controls remain.
The histogram/evidence figure is deliberately NOT auto-opened.
The orbit is January 28, 2022. NOT the April 23-24, 2023 storm.

CAVEATS:
- Patterns are idealized illustrative Gaussian antenna lobes, NOT original
  2022 antenna hardware measurements or RF degradation.
- Network station profiles give published coordinates; 2022 equipment remains
  incompletely verified. EA6TC and EU1XX positions are Maidenhead-grid estimates.
- No observed packet loss, solar-weather effects, or edge latency are displayed.
- Satellite Communications Toolbox is required for antenna patterns. On error,
  geometry playback remains available with warning.
- Only creates MATLAB objects; does not overwrite source data or outputs.

Files: praxis_ops_sat_viewer_v06.m, praxis_ops_sat_evidence_v06.m
