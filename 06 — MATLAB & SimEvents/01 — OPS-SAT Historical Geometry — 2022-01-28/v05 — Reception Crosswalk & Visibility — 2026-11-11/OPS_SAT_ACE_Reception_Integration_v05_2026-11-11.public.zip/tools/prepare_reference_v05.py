"""Prepare explicit geometry cases and run an independent Python SGP4 reference.
Reference is NOT a MATLAB execution or a receiver-performance measurement.
"""
import sys,pathlib,csv,json,hashlib,math,collections,datetime
from sgp4.api import Satrec,jday
from sgp4.propagation import gstime
BASE=pathlib.Path(__file__).resolve().parent.parent
def read(p):
    with p.open(encoding="utf-8-sig",newline="") as f:return list(csv.DictReader(f))
def write(p,rows):
    with p.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def grid6(g):
    g=g.upper()
    lon=-180+(ord(g[0])-65)*20+int(g[2])*2+(ord(g[4])-65)/12
    lat=-90+(ord(g[1])-65)*10+int(g[3])+(ord(g[5])-65)/24
    return lat+1/48,lon+1/24,1/48,1/24
C=read(BASE/"inputs/Selected_50_Receptions_Crosswalk_2026-11-11.csv")
W=read(BASE/"inputs/OPS_SAT_ACE_100_Witness_Qualification_Register_v01.csv")
F=read(BASE/"inputs/Returned_100_Frames_Reconciliation_2026-11-11.csv")
S=read(BASE/"inputs/Ground_Site_Evidence_v01.csv")
cases=[]
def add(cid,name,route,group,variant,lat,lon,alt,mask,evidence,note):
    cases.append(dict(config_id=cid,observer_match_name=name,source_route=route,
                      case_group=group,coordinate_variant=variant,lat_deg=lat,lon_deg=lon,
                      altitude_m=alt,min_elevation_deg=mask,evidence_class=evidence,assumption_note=note))
for oid in ["5369438","5375671"]:
    o=json.loads((BASE/"inputs"/("observation_"+oid+".json")).read_text())
    cm=json.loads(o["client_metadata"]);sid=str(o["ground_station"])
    name=next(x["observer_match_name"] for x in C if x["original_station_id"]==sid)
    legacy=next(x for x in S if x["source_station_id"]==sid)
    variants=[
      ("client",cm["latitude"],cm["longitude"],cm["elevation"],"Historical embedded receiver metadata"),
      ("observation",o["station_lat"],o["station_lng"],o["station_alt"],"Observation API location fields; discrepancies retained"),
      ("legacy",float(legacy["lat_deg"]),float(legacy["lon_deg"]),float(legacy["altitude_m"]),"Unchanged v01 current-profile geometry inputs")
    ]
    for variant,lat,lon,alt,evidence in variants:
        for mask in [0,5,10]:
            add("NET"+sid+"_"+variant.upper()+"_M"+str(mask),name,"network","network_site",variant,
                lat,lon,alt,mask,evidence,
                "0/5/10 degree masks are sensitivity assumptions; v01 baseline mask="+legacy["min_elevation_deg"]+" deg. No confirmed historical horizon mask.")
for name,g in [("EA6TC","JM19jn"),("EU1XX","KO33ru")]:
    lat,lon,dy,dx=grid6(g)
    points=[("CENTER",lat,lon),("SW",lat-dy,lon-dx),("SE",lat-dy,lon+dx),
            ("NW",lat+dy,lon-dx),("NE",lat+dy,lon+dx)]
    for point,la,lo in points:
        for mask in [0,10]:
            add(name+"_GRID_"+point+"_M"+str(mask),name,"sids","sids_grid",g+" "+point,
                la,lo,0,mask,"Declared six-character Maidenhead grid; approximate site",
                "Cell center/corner, sea-level height and 0/10 degree mask assumptions. No Network station ID inferred.")
    provider={(float(x["Lat"]),float(x["Lon"])) for x in F if x["Observer/Station"]==name}
    assert len(provider)==1,provider
    la,lo=provider.pop()
    for mask in [0,10]:
        add(name+"_PROVIDER_M"+str(mask),name,"sids","sids_provider_nominal","provider_two_decimal_nominal",
            la,lo,0,mask,"Provider two-decimal coordinate; privacy limited",
            "Nominal rounded coordinate only; not exact position or a bound. Unmatched reception uses shared observer position from later returned frames; sea-level/mask assumed.")
assert len(cases)==42 and len({x["config_id"] for x in cases})==42
write(BASE/"inputs/Visibility_Configurations_v05.csv",cases)
tle=(BASE/"inputs/OPS_SAT_44878_SELECTED_2022-01-28.tle").read_text().splitlines()
l1=next(l for l in tle if l.startswith("1 "));l2=next(l for l in tle if l.startswith("2 "))
def checksum(l):
    return len(l)==69 and sum(int(x) if x.isdigit() else 1 if x=="-" else 0 for x in l[:68])%10==int(l[68])
assert checksum(l1) and checksum(l2)
sat=Satrec.twoline2rv(l1,l2)
def position(t):
    jd,fr=jday(t.year,t.month,t.day,t.hour,t.minute,t.second+t.microsecond/1e6)
    err,p,_=sat.sgp4(jd,fr)
    assert err==0,err
    angle=gstime(jd+fr);c=math.cos(angle);s=math.sin(angle)
    # TEME -> pseudo-Earth-fixed: GMST rotation; zero polar motion and UT1-UTC.
    return (c*p[0]+s*p[1],-s*p[0]+c*p[1],p[2]),p
def elevation(fixed,lat,lon,alt):
    a=6378.137;f=1/298.257223563;e2=f*(2-f)
    la=math.radians(lat);lo=math.radians(lon);h=alt/1000
    n=a/math.sqrt(1-e2*math.sin(la)**2)
    site=((n+h)*math.cos(la)*math.cos(lo),(n+h)*math.cos(la)*math.sin(lo),(n*(1-e2)+h)*math.sin(la))
    delta=[fixed[i]-site[i] for i in range(3)]
    up=(math.cos(la)*math.cos(lo),math.cos(la)*math.sin(lo),math.sin(la))
    return math.degrees(math.asin(sum(delta[i]*up[i] for i in range(3))/math.sqrt(sum(x*x for x in delta))))
rows=[]
for r in C:
    t=datetime.datetime.fromisoformat(r["reception_utc"].replace("Z","+00:00"))
    fixed,_=position(t)
    for k in cases:
        if k["observer_match_name"]!=r["observer_match_name"]:continue
        el=elevation(fixed,k["lat_deg"],k["lon_deg"],k["altitude_m"])
        margin=el-k["min_elevation_deg"]
        rows.append(dict(source_json_row_1based=int(r["source_json_row_1based"]),observer=r["observer_match_name"],
           reception_utc=r["reception_utc"],config_id=k["config_id"],case_group=k["case_group"],
           elevation_deg=round(el,8),mask_deg=k["min_elevation_deg"],margin_deg=round(margin,8),
           within_access=el>=k["min_elevation_deg"],near_threshold=abs(margin)<0.05))
assert len(rows)==585
write(BASE/"reference/SGP4_Reference_Visibility_2026-11-11.csv",rows)
summary=[]
for r in C:
    rr=[x for x in rows if str(x["source_json_row_1based"])==r["source_json_row_1based"]]
    def classify(z):
        p=sum(x["within_access"] for x in z)
        return "NOT_APPLICABLE" if not z else "INSIDE_ALL_TESTED_ASSUMPTIONS" if p==len(z) else "SENSITIVE_TO_TESTED_ASSUMPTIONS" if p else "OUTSIDE_ALL_TESTED_ASSUMPTIONS"
    summary.append(dict(source_json_row_1based=r["source_json_row_1based"],observer=r["observer_match_name"],
        reception_utc=r["reception_utc"],returned_frame_id=r["returned_frame_id"],provider_match_missing=r["match_status"]!="MATCHED_METADATA",
        configuration_checks=len(rr),checks_inside=sum(x["within_access"] for x in rr),geometry_status=classify(rr),
        grid_geometry_status=classify([x for x in rr if x["case_group"]=="sids_grid"]),
        minimum_margin_deg=min(x["margin_deg"] for x in rr),minimum_elevation_deg=min(x["elevation_deg"] for x in rr),
        maximum_elevation_deg=max(x["elevation_deg"] for x in rr),execution_engine="Python sgp4 2.25 reference, NOT MATLAB"))
write(BASE/"reference/SGP4_Reference_50_Receptions_2026-11-11.csv",summary)
# A mathematically equivalent zero-sign convention in observation TLEs
# must not change the selected satellite state.
equiv=[]
for oid in ["5369438","5375671"]:
    o=json.loads((BASE/"inputs"/("observation_"+oid+".json")).read_text())
    assert checksum(o["tle1"]) and checksum(o["tle2"])
    ss=Satrec.twoline2rv(o["tle1"],o["tle2"])
    t=datetime.datetime(2022,1,28,17,48,tzinfo=datetime.timezone.utc)
    jd,fr=jday(t.year,t.month,t.day,t.hour,t.minute,t.second)
    e,a,_=sat.sgp4(jd,fr);e2,z,_=ss.sgp4(jd,fr)
    delta=math.sqrt(sum((a[i]-z[i])**2 for i in range(3)))*1000
    assert e==0 and e2==0 and delta<1e-6
    equiv.append(dict(observation_id=oid,position_difference_m=delta))
assert len(C)==50 and len(W)==100 and len(F)==100
assert len({r["source_json_row_1based"] for r in C})==50
assert len({(x["config_id"],x["source_json_row_1based"]) for x in rows})==585
weights=collections.Counter(w["source_json_row_1based"] for w in W)
assert len(weights)==50 and all(n==2 for n in weights.values())
by_obs={}
for name in sorted({r["observer"] for r in summary}):
    z=[x for x in summary if x["observer"]==name]
    by_obs[name]=dict(receptions=len(z),ace_rows=sum(weights[x["source_json_row_1based"]] for x in z),
                     all=collections.Counter(x["geometry_status"] for x in z),
                     grid=collections.Counter(x["grid_geometry_status"] for x in z))
# Semantic control checks: a satellite above the site zenith must be near 90
# degrees; an antipodal site must be occulted. These test AER axis/sign.
assert abs(elevation((6878.137,0,0),0,0,0)-90)<1e-8
assert elevation((6878.137,0,0),0,180,0)<-89.99
report=dict(archive_date="2026-11-11",engine="Python sgp4 2.25 with WGS84 ground sites",
    matlab_execution_status="NOT_RUN_NO_MATLAB_IN_CLOUD_RUNTIME",
    geometry_check_count=len(rows),configuration_count=len(cases),by_observer=by_obs,
    near_threshold_case_count=sum(x["near_threshold"] for x in rows),
    global_smallest_abs_margin_deg=min(abs(x["margin_deg"]) for x in rows),
    matching_receptions=49,unmatched_receptions=1,existing_ace_rows=100,
    original_tle_checksums="PASS",network_tle_state_equivalence=equiv,
    controls="PASS: site-zenith +90 deg; antipodal occultation; unique case keys and 2 ACE rows per reception.",
    frame_conversion="TEME to pseudo-Earth-fixed by Vallado GMST using UTC as UT1; no polar motion. Approximate reference, not identical MATLAB implementation.",
    caution="No frame reception counterfactual, packet-loss calculation, continuous-service or architecture-performance claim. Native MATLAB execution must be recorded separately.")
(BASE/"validation/Independent_SGP4_Validation_2026-11-11.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))

