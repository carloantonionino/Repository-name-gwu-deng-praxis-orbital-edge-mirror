OPS-SAT ACE — Provisional 90 SiDS witness geometry test, v03
2026-11-08

PURPOSE
Run the remaining 90 historical ACE/SiDS reception witnesses against the SAME
OPS-SAT (NORAD 44878) historical TLE as the working v02 geometry.
This does NOT change the validated Ground-versus-Edge DES experiment.

FROZEN SOURCE
100 ACE witnesses: 10 Network-origin observations with original station IDs
+ 90 SiDS records: EA6TC JM19jn (46) and EU1XX KO33ru (44).
This is one spacecraft, NOT 100 satellites or 200 historical observations.

HOW TO EXECUTE
1. Download the v03 ZIP. Extract its three files to:
   C:\Users\carlo\OneDrive\Desktop\AA GWU PRAXIS\MATLAB Visualizer Main
   Keep original v02 files in place; the names are distinct.
2. In MATLAB's Command Window:
   cd('C:\Users\carlo\OneDrive\Desktop\AA GWU PRAXIS\MATLAB Visualizer Main')
   result90 = praxis_check_90_sids_v03;
   tabulate(result90.geometry_classification)
3. Examine SiDS_90_Geometry_Sensitivity_v03.csv.
4. Preserve your original v02 ID_Verified_Reception_Geometry_Check_v02.csv.

INTERPRETATION
Five locations are tested per 6-character Maidenhead grid (center + corners).
Elevation masks of 0 and 10 degrees are sensitivity assumptions, not
historic validated receiver configurations. Altitude is assumed 0 m.
The output reports how many of 10 combinations predicted access for each
historical reception witness. 90/90 agreement is NOT guaranteed or
pre-declared. Outliers need investigation, not overwriting.

The archived 2022 TLE epoch is ~6.9 h before the ACE midpoint. Propagated
SGP4 geometry is a prediction, not ground-truth RF measurement.
No derived station ID is inserted for SiDS records; original provenance
remains unchanged.

NASA OMNI provides Earth-bow-shock time-shifted environmental context (IMF
and solar-wind variables), NOT directly measured OPS-SAT link attenuation,
radio propagation loss, packet loss, or solar-radiation-induced outages.
The DES processing/transmission durations and 600s-up/120s-down link are
synthetic, seeded model parameters. The geometry test does not replace them.
