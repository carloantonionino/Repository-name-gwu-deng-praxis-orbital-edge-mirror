function result = praxis_ops_sat_viewer_v07(varargin)
% PRA XIS OPS-SAT v07 | provenance-informed visual overlay ONLY, 11 November 2026
% Preserves v05 inputs and historical geometry. Does not change DES model.
% Requires MATLAB satelliteScenario. Antenna bloom requires SatCom Toolbox.
% EXAMPLE: v = praxis_ops_sat_viewer_v06('speed',5,'blooms','all');
% To view evidence AFTER playback: praxis_ops_sat_evidence_v06(v)

p = inputParser;
addParameter(p,'speed',5,@(x)isnumeric(x)&&isscalar(x)&&x>0);
addParameter(p,'blooms','all',@(x)any(strcmpi(string(x),["off","satellite","all"])));
addParameter(p,'packageDir',fullfile('C:\Users\carlo\OneDrive\Desktop\AA GWU PRAXIS\PRIME\Mtg 5 - Oct 30, 2026\MATLAB docs\MATLAB V1','OPS_SAT_ACE_Reception_Integration_v05'),@(x)ischar(x)||isstring(x));
parse(p,varargin{:});
speed = p.Results.speed;
blooms = lower(string(p.Results.blooms));
root = char(p.Results.packageDir);
tle = fullfile(root,'inputs','OPS_SAT_44878_SELECTED_2022-01-28.tle');
inputCsv = fullfile(root,'inputs','Selected_50_Receptions_Crosswalk_2026-11-11.csv');
assert(isfile(tle),'Historical OPS-SAT TLE not found in v05 inputs.');
assert(isfile(inputCsv),'50-reception crosswalk not found in v05 inputs.');
assert(contains(fileread(tle),'1 44878U 19092F'),'TLE does not match OPS-SAT / NORAD 44878.');

% Use v05 run's latest timestamped output for classifications, if present.
outRoot = fullfile(root,'outputs');
outList = dir(fullfile(outRoot,'*','MATLAB_Selected_50_Reception_Check_v05.csv'));
assert(~isempty(outList),'Run RUN_RECEPTION_CHECK_v05 first; no verified output CSV found.');
[~,order] = sort([outList.datenum], 'descend');
selectedOut = fullfile(outList(order(1)).folder, outList(order(1)).name);
T = readtable(selectedOut,'TextType','string');
assert(height(T)==50,'Expected precisely 50 selected historical receptions.');

startUTC = datetime(2022,1,28,17,42,49,'TimeZone','UTC');
endUTC   = datetime(2022,1,28,17,54,19,'TimeZone','UTC');
sc = satelliteScenario(startUTC,endUTC,1);
sat = satellite(sc,tle,'Name','OPS-SAT 44878 (historical TLE)','OrbitPropagator','sgp4');
sat.MarkerColor = [0.19 0.83 0.99];
sat.MarkerSize = 10;

% Coordinates and visible labels retained from v05 controlled source.
% Network: published current profile, NOT verified 2022 hardware.
% SiDS: Maidenhead cell centers, NOT proven historical receiver locations.
siteNames = ["ESA ESTEC [ID839]";"DL5FAB [ID2504]"; ...
    "EA6TC [JM19jn PROVISIONAL]";"EU1XX [KO33ru PROVISIONAL]"];
lat = [52.217;49.859;39.559;53.854167];
lon = [4.423;8.660;2.781;27.458333];
alt = [5;220;0;0];
minEl = [5;10;10;10]; % SiDS values 10 deg illustrative, not historical facts.
siteColors = [0.20 0.84 0.53;0.20 0.84 0.53; ...
              1.00 0.65 0.19;1.00 0.65 0.19];
G = cell(4,1); A = cell(4,1);
for k = 1:4
    G{k} = groundStation(sc,lat(k),lon(k), ...
        'Altitude',alt(k),'MinElevationAngle',minEl(k), ...
        'Name',char(siteNames(k)));
    G{k}.MarkerColor = siteColors(k,:);
    G{k}.MarkerSize = 9;
    A{k} = access(sat,G{k});
    A{k}.LineColor = siteColors(k,:);
    A{k}.LineWidth = 2;
end

viewer = satelliteScenarioViewer(sc);
show(sat);
for k = 1:4
    show(G{k});
    show(A{k});
end
try
    groundTrack(sat,'LeadTime',600,'TrailTime',600);
catch err
    warning('Ground track not displayed: %s',err.message);
end

% All blooms are VISUAL demonstrations of assumed Gaussian gain patterns,
% not actual OPS-SAT or 2022 SatNOGS antenna configuration or RF strength.
patterns = {};
if blooms ~= "off"
    try
        tx = transmitter(sat,'Frequency',437.2e6, ...
            'Power',-3, ... % 27 dBm nominal sensitivity assumption, not 2022 flight measurement
            'Name','ILLUSTRATIVE OPS-SAT UHF antenna');
        patterns{end+1} = pattern(tx, ...
            'Viewer',viewer,'Size',180000, ...
            'Colormap','autumn','Transparency',0.35,'Resolution','medium');
        if blooms == "all"
            for k = 1:2 % Network stations only; SiDS antenna types unknown.
                rx = receiver(G{k},'Name',sprintf('ILLUSTRATIVE receiver %d',k));
                patterns{end+1} = pattern(rx,437.2e6, ...
                    'Viewer',viewer,'Size',95000, ...
                    'Colormap','autumn','Transparency',0.30,'Resolution','medium');
            end
        end
        fprintf('Illustrative antenna blooms added. NOT measured gain.\n');
    catch err
        warning(['Blooms unavailable: %s. Requires Satellite Communications ' ...
                 'Toolbox. Geometry viewer is unchanged.'],err.message);
    end
end

fprintf('OPS-SAT v07 documented RF parameters | %d distinct v05 receptions loaded\n',height(T));
fprintf('ESA OPS-SAT UHF 437.2 MHz / AX100; example power 27 dBm, assumed.\n');
fprintf('SatNOGS current antennas: ESTEC cross-Yagi UHF, DL5FAB turnstile UHF.\n');
fprintf('Pattern shape remains default MATLAB Gaussian: NOT historical gain.\n');
fprintf('GREEN: Network ID; AMBER: provisional SiDS grid estimate\n');
fprintf('Speed %gx; satellite + 4 stations, January 28, 2022.\n',speed);
fprintf('Evidence figure is separate: praxis_ops_sat_evidence_v06(v)\n');
fprintf('The scene and viewer are not closed by this function.\n');
result = struct('scenario',sc,'satellite',sat,'viewer',viewer, ...
    'stations',{G},'accesses',{A},'patterns',{patterns},'rfFacts',struct('frequencyHz',437.2e6, ...
    'examplePowerdBm',27,'examplePowerdBW',-3, ...
    'powerIsHistorical',false,'patternIsHistorical',false), ...
    'receptions',T,'sourceOutput',selectedOut);
play(sc,'PlaybackSpeedMultiplier',speed);
end
