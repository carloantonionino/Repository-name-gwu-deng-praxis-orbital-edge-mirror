PROVENANCE-INFORMED V07 EXPERIMENTAL VIEWER (NOV 11 2026)

Purpose: preserve existing v06 globe / four stations / access lines / historical 2022 TLE; add defensible radio metadata and explicitly modeled TX power.

Usage: Extract this ZIP separately, then in MATLAB Command Window:
  cd('C:\Users\carlo\OneDrive\Desktop\AA GWU PRAXIS\PRIME\Mtg 5 - Oct 30, 2026\MATLAB docs\MATLAB V1\Blooms v1')
  addpath(pwd)
  v = praxis_ops_sat_viewer_v07('speed',2,'blooms','satellite');

Note: copy praxis_ops_sat_viewer_v07.m into your Blooms v1 directory, beside the existing v06 script, OR point MATLAB to the extracted v07 folder instead. v07 still reads original v05 data using its configured location. It DOES NOT edit those files.

v07 uses 27 dBm (-3 dBW) as a sensitivity midpoint within the published AX100 adjustable power range of 24-30 dBm. Actual Jan 28 2022 OPS-SAT transmitter setting remains unknown. This does not calibrate the antenna gain or demonstrate a received signal level.

CRITICAL: default MATLAB Gaussian pattern continues to draw the teardrop. It is NOT a model of a known OPS-SAT flight antenna, ESTEC crossed-Yagi or DL5FAB turnstile. The v07 output labels are unchanged from v06. Current ground-station antenna TYPES are kept in the RF_Parameter_Register_v07.csv with explicit historical limits.

Citations and restrictions: RF_Parameter_Register_v07.csv.
Unexecuted in user's licensed MATLAB. Keep original v06 as rollback. No edits to DES, v05 or source registers.
