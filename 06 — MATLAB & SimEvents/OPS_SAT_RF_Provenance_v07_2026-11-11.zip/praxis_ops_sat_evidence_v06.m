function praxis_ops_sat_evidence_v06(v)
% Opens a separate evidence figure without closing the 3D viewer.
T = v.receptions;
status = string(T.geometry_status);
robust = nnz(status=="INSIDE_ALL_TESTED_ASSUMPTIONS");
sensText = lower(string(T.visibility_sensitive_to_site_or_mask));
sensitive = nnz(sensText=="1" | sensText=="true");
if sensitive == 0
    sensitive = nnz(contains(status,"SENSITIVE"));
end
outside = nnz(contains(status,"OUTSIDE_ALL"));
fig = figure('Name','OPS-SAT v05 reception geometry evidence', ...
    'Color',[0.09 0.15 0.24],'Position',[100 90 980 600]);
tiledlayout(fig,2,1,'Padding','compact','TileSpacing','compact');
ax = nexttile;
b = bar(ax,[robust sensitive outside],'FaceColor','flat');
b.CData = [0.24 0.74 0.96;1.00 0.65 0.19;0.94 0.33 0.36];
set(ax,'XTickLabel',{'Inside all assumptions','Assumption-sensitive','Outside all'});
ylabel(ax,'Distinct receptions');
title(ax,sprintf('v05 verification: %d historical reception records',height(T)));
grid(ax,'on');
ax2 = nexttile;
rawTimes = datetime(T.reception_utc, ...
    'InputFormat',"yyyy-MM-dd'T'HH:mm:ss'Z'",'TimeZone','UTC');
names = ["ESA","DL5FAB","EA6TC","EU1XX"];
colors = [0.20 0.84 0.53;0.20 0.84 0.53; ...
          1.00 0.65 0.19;1.00 0.65 0.19];
for k = 1:4
    mask = contains(upper(string(T.observer_as_recorded)),upper(names(k)));
    scatter(ax2,rawTimes(mask),k*ones(nnz(mask),1),45, ...
        'MarkerFaceColor',colors(k,:),'MarkerEdgeColor','none');
    hold(ax2,'on');
end
set(ax2,'YTick',1:4,'YTickLabel',{'ESTEC 839','DL5FAB 2504', ...
    'EA6TC provisional','EU1XX provisional'},'YLim',[.5 4.5]);
xlabel(ax2,'Original reception timestamps (UTC), January 28, 2022');
title(ax2,'Time-aligned reception evidence; not packet-loss measurement');
grid(ax2,'on');
end
