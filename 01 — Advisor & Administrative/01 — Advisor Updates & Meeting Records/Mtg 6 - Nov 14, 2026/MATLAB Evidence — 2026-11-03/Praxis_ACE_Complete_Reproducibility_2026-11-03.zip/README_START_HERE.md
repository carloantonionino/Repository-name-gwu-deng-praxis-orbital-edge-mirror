# Praxis — Simultaneous ACE MATLAB Reproduction Package

Prepared for author review, 3 November 2026. Source: controlled NAC Google Drive / Praxis.
This is a reversible copy for research review, not a change to the authoritative files.

## Minimal reproducible execution — BASE MATLAB
1. Unzip this package. Open MATLAB.
2. Set Current Folder to `MATLAB_Baseline2_Simultaneous_ACE` (the folder with `run_all.m` and `data/`).
3. In the MATLAB Command Window:

   baseline = run_all('figures', 0);
   run_all;  % optional, renders/exports figures

The first command compares the 10-replication result against exported workbook expectations (absolute tolerance 1e-6).
Outputs go into `MATLAB_Baseline2_Simultaneous_ACE/output/`.

## Optional Simulink + SimEvents model
With Simulink and SimEvents installed:

   cd simevents
   run_simevents
   open_system('ACE_GroundVsEdge')

This runs one SimEvents replication and compares entity-level output with the MATLAB engine. It is NOT the 10-replication summary and not a 20,000-run test. Aerospace Toolbox is not needed for either stage.

## Optional provenance audit against original downloaded sources
Using Python 3 standard library from this ZIP's top-level folder:

   python verify_ace_sources.py

The script checks each of the 100 accepted rows against the OPSSAT-AD telemetry and label, the one-based SatNOGS JSON witness row, the NASA OMNI UTC minute, and arrival/lag consistency. It does NOT claim environmental causality, observed RTT/packet loss, physical link outage, or operational validation.

## What is true and what is modeled?
- The exact 100 selected OPS-SAT telemetry times are historical empirical records.
- The SatNOGS observations have verified prior reception timestamps and NORAD ID 44878.
- OMNI is temporally aligned solar-wind/environmental context, NOT a colocated measurement of that OPS-SAT radio path.
- `raw_mb=300`, `rate_mbps=100`, `output_fraction=0.25`, service times, 600s up/120s down, deadline/staleness limits are synthetic comparison assumptions.
- The `expected_*.csv` tables are exported simulation results from the Excel v9 baseline; they are not satellite measurements.

## Current sample size and future scale
The displayed figures represent 10 replications × 100 ACE observations × 2 architectures = 2,000 entity-path outputs (1,000 matched comparisons), with 10 independent seeded replication summaries for the stated CI. A 20,000 architecture-replication goal (10,000 Ground + 10,000 Edge replications) can be requested using `run_all('reps',10000,'figures',0)` ONLY after the baseline passes and resource limits are assessed. This would generate 2,000,000 entity-path outputs because each replication replays 100 observations. No such scaled result is claimed here.

**Seed:** each replication `r` uses X0=54321+1000*r with Park-Miller multiplicative sequence a=16807, m=2147483647; service time=-mean*log(U). This is documented in the source code.

## Preservation and provenance
`MATLAB_Baseline2_Simultaneous_ACE/`: copied runnable `.m`, `.slx` and `data/*.csv`, with native MATLAB extensions restored from Drive-stored `.m.txt` content (file bytes unchanged).
`SOURCE_DATA/`: byte-preserved downloaded original OPSSAT-AD `dataset.csv`, `segments.csv`, LICENSE; SatNOGS OPS-SAT JSON; NASA OMNI 1-minute data and companion `.fmt` description.
`SOURCE_MANIFEST.csv`: SHA-256 and Drive file URLs for each source. Do not rely on a filename alone to establish data provenance.

This package is for the bounded historical cohort; it does not need every dataset ever collected during the Praxis (WetLinks, CINC, CAIDA etc. are supporting/candidate streams and are not the accepted simultaneous baseline).
