#!/usr/bin/env python3
"""Reproducibility audit for the ACCEPTED Jan 28 2022 ACE cohort.
Uses Python 3 standard library. No network calls. No dataset modification.
Run from ZIP root: python verify_ace_sources.py
"""
from pathlib import Path
import csv,json,hashlib,datetime as dt,statistics,sys
base=Path(__file__).resolve().parent
runtime=base/'MATLAB_Baseline2_Simultaneous_ACE'/'data'
raw=base/'SOURCE_DATA'
def table(path):
 with path.open('r',encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
prov=table(runtime/'ace_provenance.csv');cohort=table(runtime/'ace_cohort.csv')
rows=table(raw/'dataset.csv')
segments={}
with (raw/'segments.csv').open('r',encoding='utf-8-sig',newline='') as f:
 for d in csv.DictReader(f):
  if d['channel']=='CADC0873' and d['timestamp'].startswith('2022-01-28T17:'):
   stamp=d['timestamp'].replace('T',' ').replace('.000Z','').replace('Z','')
   segments[(stamp,d['segment'],d['channel'])]=d
json_data=json.loads((raw/'OPS-SAT_2022-01-26_to_2022-01-29_COMPLETE.json').read_text(encoding='utf-8-sig'))
labels={(d['segment'],d['channel'],d['anomaly']) for d in rows}
minutes=set()
for line in (raw/'omni_min_hOnlv3ZjMa 2.txt').read_text(encoding='utf-8-sig').splitlines():
 p=line.split()
 if p:minutes.add(f'{p[0]}-01-{int(p[1]):02d} {int(p[2]):02d}:{int(p[3]):02d}:00')
failures=[]
if len(prov)!=100 or len(cohort)!=100: failures.append('Expected 100 accepted cohort rows')
if len(rows)!=2123:failures.append('Dataset segment count differs from 2,123')
if len(json_data)!=560:failures.append('SatNOGS JSON count differs from 560')
reference=dt.datetime.fromisoformat(prov[0]['prior_comm_utc'])
for p,c in zip(prov,cohort):
 eid=p['entity'];t=dt.datetime.fromisoformat(p['telemetry_utc']);tcomm=dt.datetime.fromisoformat(p['prior_comm_utc'])
 if eid!=c['entity']:failures.append(f'Entity order mismatch {eid}')
 if (p['telemetry_utc'],p['segment'],p['channel']) not in segments:failures.append(f'Telemetry mismatch {eid}')
 if (p['segment'],p['channel'],p['anomaly']) not in labels:failures.append(f'OPSSAT label mismatch {eid}')
 ix=int(p['witness_json_row'])-1
 if not (0<=ix<len(json_data) and json_data[ix]['timestamp'].replace('T',' ').removesuffix('Z')==p['prior_comm_utc'] and json_data[ix]['norad_cat_id']==44878):failures.append(f'SatNOGS mismatch {eid}')
 if p['omni_utc_minute'] not in minutes:failures.append(f'OMNI mismatch {eid}')
 if abs((t-tcomm).total_seconds()-float(p['comm_age_s']))>1e-8:failures.append(f'Lag mismatch {eid}')
 if abs((t-reference).total_seconds()-float(c['arrival_offset_s']))>1e-8:failures.append(f'Arrival offset mismatch {eid}')
# Cross-check the original expected workbook calculations with the 10 exported replications.
exp=table(runtime/'expected_replications.csv')
comp={d['metric']:float(d['value']) for d in table(runtime/'expected_comparison.csv')}
if len(exp)!=10:failures.append('Expected-replication row count != 10')
else:
 diffs=[float(v['g_mean'])-float(v['e_mean']) for v in exp]
 m=statistics.mean(diffs); sd=statistics.stdev(diffs)
 if abs(m-comp['lat_mean_diff'])>1e-8:failures.append('Paired mean mismatch')
 if abs(sd-comp['lat_sd'])>1e-8:failures.append('Paired SD mismatch')
 if abs(m-comp['lat_ci_low']-comp['lat_half'])>1e-8:failures.append('Lower CI mismatch')
print('SOURCE_AUDIT', 'PASS' if not failures else 'FAIL')
print('accepted',len(prov),'opssat_segments',len(rows),'satnogs_records',len(json_data),'omni_minute_records',len(minutes))
print('utc_start',prov[0]['telemetry_utc'],'utc_end',prov[-1]['telemetry_utc'])
print('source match categories: timestamp / segment / label / SatNOGS witness / OMNI minute / offset')
print('paired_mean_s',round(comp['lat_mean_diff'],4),'95pct_ci_s',round(comp['lat_ci_low'],4),round(comp['lat_ci_high'],4))
print('IMPORTANT: original telemetry timestamps are empirical; 300MB, 100Mbps, link schedule and processing times are simulation assumptions.')
for line in failures[:30]:print('FAILURE:',line)
sys.exit(0 if not failures else 1)
